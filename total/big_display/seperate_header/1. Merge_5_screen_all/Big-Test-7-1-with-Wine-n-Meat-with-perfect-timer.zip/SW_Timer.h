void call_WIFI_setup(const char ssid[], const char password[]);
void set_magamTime(int y, int m, int d, int h, int min);
int get_RemainMin();
